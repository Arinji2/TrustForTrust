function imageEnlarge() {
    document.getElementById('1').style.height="40%";
    document.getElementById('1').style.width="40%";
    }
   function imageReset() {
    document.getElementById('1').style.width="500px";
    }

   function SignUpButton() {
    document.getElementById('3').window.location.href='https://web.trustfortrust.cf/signup.php';
    }

	SA.redirection_mobile ({
		mobile_url : "https://web.trustfortrust.cf/mobile-login.html",
		mobile_prefix : "https"
	});
